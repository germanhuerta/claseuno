package cl.duoc.cinehoyts.Service;

import cl.duoc.cinehoyts.DTO.PeliculaDTO;
import java.util.List;

public interface IPelicula {
public void Guardar(PeliculaDTO p);
public void Editar(int i, PeliculaDTO p);
public List<PeliculaDTO> listar();
public void Eliminar(PeliculaDTO p);
public PeliculaDTO BPelicula(String NombreP);
public PeliculaDTO BDirector(String Director);
public PeliculaDTO BId(int id);
public PeliculaDTO BCategoria(String categoria);
public PeliculaDTO BDuracion(String Duracion);
}
