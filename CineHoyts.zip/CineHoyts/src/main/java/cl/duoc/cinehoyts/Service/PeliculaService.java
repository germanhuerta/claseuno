package cl.duoc.cinehoyts.Service;

import cl.duoc.cinehoyts.DTO.PeliculaDTO;
import java.util.ArrayList;
import java.util.List;

public class PeliculaService implements IPelicula {

    List<PeliculaDTO> lista;
    private static int contid = 1;

    public PeliculaService() {
        this.lista = new ArrayList<>();
    }

    @Override
    public void Guardar(PeliculaDTO p) {
        p.setId(contid++);
        this.lista.add(p);
    }

    @Override
    public void Editar(int i, PeliculaDTO p) {
        this.lista.set(i, p);
    }

    @Override
    public List<PeliculaDTO> listar() {
        return this.lista;
    }

    @Override
    public void Eliminar(PeliculaDTO p) {
        this.lista.remove(p);
    }

    @Override
    public PeliculaDTO BPelicula(String NombreP) {

        return null;
    }

    @Override
    public PeliculaDTO BDirector(String Director) {

        return null;
    }

    @Override
    public PeliculaDTO BId(int id) {

        return null;
    }

    @Override
    public PeliculaDTO BCategoria(String categoria) {

        return null;
    }

    @Override
    public PeliculaDTO BDuracion(String Duracion) {

        return null;
    }
}