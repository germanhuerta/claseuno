package cl.duoc.cinehoyts.DTO;

public class PeliculaDTO {
    private int id;
    private String pelicula;
    private String Director;
    private String Categoria;
    private String Duracion;

    private static int contid = 1;

    public PeliculaDTO() {
        this.id = contid++;
        this.pelicula = "";
        this.Director = "";
        this.Categoria = "";
        this.Duracion = "";
    }

    public PeliculaDTO(String pelicula, String Director, String Categoria, String Duracion) {
        this.id = contid++;
        this.pelicula = pelicula;
        this.Director = Director;
        this.Categoria = Categoria;
        this.Duracion = Duracion;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPelicula() {
        return pelicula;
    }

    public void setPelicula(String pelicula) {
        this.pelicula = pelicula;
    }

    public String getDirector() {
        return Director;
    }

    public void setDirector(String Director) {
        this.Director = Director;
    }

    public String getCategoria() {
        return Categoria;
    }

    public void setCategoria(String Categoria) {
        this.Categoria = Categoria;
    }

    public String getDuracion() {
        return Duracion;
    }

    public void setDuracion(String Duracion) {
        this.Duracion = Duracion;
    }

    @Override
    public String toString() {
        return "\n" + "ID: " + this.id + "\n"
                + "Pelicula: " + this.pelicula + "\n"
                + "Director: " + this.Director + "\n"
                + "Categoria: " + this.Categoria + "\n"
                + "Duracion: " + this.Duracion;
    }
}
